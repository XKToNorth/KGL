import os
import numpy as np
import torch
from sklearn.model_selection import KFold
from torchvision import transforms, datasets
from torch.utils.data import Dataset, DataLoader

# 自定义数据集类，确保 transform 100% 生效
class CustomImageDataset(Dataset):
    def __init__(self, image_folder, indices, transform=None):
        self.image_folder = image_folder
        self.indices = indices
        self.transform = transform

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        real_idx = self.indices[idx]
        img, label = self.image_folder[real_idx]
        if self.transform:
            img = self.transform(img)
        return img, label

# ==============================================原data_load函数==========================================================

# def data_load(root_path, dir, batch_size, numworker):
#     full_dataset = datasets.ImageFolder(root=os.path.join(root_path, dir))
#
#     # 划分索引
#     class_indices = {}
#     for idx, (_, label) in enumerate(full_dataset):
#         class_indices.setdefault(label, []).append(idx)
#
#     train_idx, val_idx, test_idx = [], [], []
#     for indices in class_indices.values():
#         np.random.shuffle(indices)
#         n = len(indices)
#         train_idx.extend(indices[:int(0.6 * n)])
#         val_idx.extend(indices[int(0.6 * n):int(0.8 * n)])
#         test_idx.extend(indices[int(0.8 * n):])
#
#     # 定义 transform（确保包含 ToTensor）
#     train_transform = transforms.Compose([
#         transforms.RandomResizedCrop(224),
#         transforms.RandomHorizontalFlip(),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                              std=[0.229, 0.224, 0.225])
#     ])
#
#     val_test_transform = transforms.Compose([
#         transforms.CenterCrop(224),
#         transforms.ToTensor(),
#         transforms.Normalize(mean=[0.485, 0.456, 0.406],
#                              std=[0.229, 0.224, 0.225])
#     ])
#
#     # 包装数据集
#     train_dataset = CustomImageDataset(full_dataset, train_idx, transform=train_transform)
#     val_dataset = CustomImageDataset(full_dataset, val_idx, transform=val_test_transform)
#     test_dataset = CustomImageDataset(full_dataset, test_idx, transform=val_test_transform)
#
#     print(f"训练集样本数: {len(train_dataset)}")
#     print(f"验证集样本数: {len(val_dataset)}")
#     print(f"测试集样本数: {len(test_dataset)}")
#
#     train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=numworker)
#     val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=numworker)
#     test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=numworker)
#
#     return train_loader, val_loader, test_loader

#============================================新的data_load函数===========================================================

def data_load(root_path, dir, batch_size, numworker, n_splits=5):
    full_dataset = datasets.ImageFolder(root=os.path.join(root_path, dir))

    # 划分测试集（保持 20%）
    class_indices = {}
    for idx, (_, label) in enumerate(full_dataset):
        class_indices.setdefault(label, []).append(idx)

    test_idx = []
    train_val_idx = []
    for indices in class_indices.values():
        np.random.shuffle(indices)
        n = len(indices)
        split = int(0.8 * n)
        train_val_idx.extend(indices[:split])
        test_idx.extend(indices[split:])

        train_transform = transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

        val_test_transform = transforms.Compose([
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])

    # 生成 K 折划分
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    folds = []
    for train_index, val_index in kf.split(train_val_idx):
        folds.append((
            [train_val_idx[i] for i in train_index],
            [train_val_idx[i] for i in val_index]
        ))



    # 返回测试集和折叠信息
    test_dataset = CustomImageDataset(full_dataset, test_idx, transform=val_test_transform)
    return folds, full_dataset, test_dataset, train_transform, val_test_transform
