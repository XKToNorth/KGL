import os
import torch
from jinja2.nodes import args_as_const
from torch import nn
import argparse
import dataloader
from classifier import Model4Classifier
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score
)
from classifier import BaseClassifier, EnsembleModel
import numpy as np
from torch.utils.data import DataLoader
from dataloader import CustomImageDataset

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description='Course_for_OfficeHome')
# 模型的基本参数
parser.add_argument('--backbone', type=str, default='resnet18')#resnext50_32x4d resnet50
parser.add_argument('--hidden_dim', type=int, default=512) #分类头全连接层的神经元数量
# 数据的基本参数
parser.add_argument('--data_path', type=str, default="OfficeHome")
parser.add_argument('--fold_name', type=str, default="Real World")
parser.add_argument('--batch_size', type=int, default=8)
parser.add_argument('--class_num', type=int, default=65)
parser.add_argument('--workers', type=int, default=8)
# 训练阶段的基本参数
parser.add_argument('--epochs', type=int, default=150)
parser.add_argument('--iters_per_epoch', type=int, default=80)
parser.add_argument('--lr', type=float, default=3e-4)
parser.add_argument('--lr_decay', type=float, default=1e-4)
parser.add_argument('--lr_scheduler', type=bool, default=True)
parser.add_argument('--momentum', type=float, default=0.9)
parser.add_argument('--decay', type=float, default=1e-3)
parser.add_argument('--temp', type=float, default=0.5)
parser.add_argument('--seed', type=int, default=42)

args = parser.parse_args()
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

#=======================================================================================================================

def train_single_model(args, train_dataset, val_dataset, model_name):
    """训练单个模型并返回最佳模型（包含完整训练逻辑）"""
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.workers
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers
    )

    # 初始化模型
    args.backbone = model_name
    model = BaseClassifier(args).to(DEVICE)
    criterion = nn.CrossEntropyLoss().to(DEVICE)

    # 优化器设置（保持与原项目一致）
    optimizer = torch.optim.Adam(
        [{'params': model.backbone.parameters(), 'lr': args.lr},
         {'params': model.classifier.parameters(), 'lr': args.lr}],
        lr=args.lr,
        weight_decay=args.lr_decay
    )

    # 学习率调度器
    if args.lr_scheduler:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=int(args.epochs * 0.5),
            eta_min=1e-5
        )

    # 训练参数初始化
    best_val_acc = 0.0
    best_model = None

    # 训练循环
    for epoch in range(args.epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        # 训练阶段
        for batch_idx, (inputs, labels) in enumerate(train_loader):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            # 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # 统计指标
            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

        # 验证阶段
        model.eval()
        val_correct = 0
        val_total = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
                outputs = model(inputs)
                _, predicted = torch.max(outputs, 1)
                val_total += labels.size(0)
                val_correct += (predicted == labels).sum().item()

        # 计算指标
        train_acc = 100. * correct / total
        val_acc = 100. * val_correct / val_total

        # 更新学习率
        if args.lr_scheduler:
            scheduler.step()

        # 保存最佳模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_model = type(model)(args)  # 创建新实例
            best_model.load_state_dict(model.state_dict())
            best_model.to(DEVICE)

        # 打印日志
        print(f"[{model_name}] Epoch {epoch + 1}/{args.epochs} | "
              f"Train Acc: {train_acc:.2f}% | "
              f"Val Acc: {val_acc:.2f}% | "
              f"Best Val Acc: {best_val_acc:.2f}%")

    return best_model


# if __name__ == "__main__":
#     ######## 数据
#     root_dir = args.data_path
#     fold_name = args.fold_name
#     train_loader, val_loader, test_loader = dataloader.data_load(root_dir,fold_name,args.batch_size, args.workers)
#
#     ##### 模型
#     model = Model4Classifier(args).to(DEVICE)
#     criterion = nn.CrossEntropyLoss().to(DEVICE)
#
#     optimizer = torch.optim.Adam(
#         [{'params':model.backbone.parameters(), 'lr':args.lr},
#          {'params':model.classifier.parameters(), 'lr':args.lr}
#         ],  lr=args.lr, weight_decay=args.lr_decay)
#
#     if args.lr_scheduler:
#         scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(args.epochs * 0.5), eta_min=1e-5)
#
#     ##### 训练参数初始化
#     best_val_acc = 0.0
#     train_loss_history, val_acc_history = [], []
#
#     for epoch in range(args.epochs):
#         #### 模型训练阶段
#         model.train()
#         running_loss = 0.0
#         correct = 0
#         total = 0
#
#         for batch_idx, (inputs, labels) in enumerate(train_loader):
#             inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
#
#             ### 前向传播
#             outputs = model(inputs)
#             loss = criterion(outputs, labels)
#
#             ### 反向传播与优化
#             optimizer.zero_grad()
#             loss.backward()
#             optimizer.step()
#
#             ### 统计训练指标
#             running_loss += loss.item()
#             _, predicted = torch.max(outputs, 1)
#             total += labels.size(0)
#             correct += predicted.eq(labels).sum().item()
#
#         # 计算epoch训练指标
#         train_loss = running_loss / len(train_loader)
#         train_acc = 100. * correct / total
#         train_loss_history.append(train_loss)
#
#         print(f"Epoch [{epoch + 1}/{args.epochs}], Training Loss: {train_loss:.4f}, Training Accuracy: {train_acc:.2f}%")
#
#         #### 模型验证阶段
#         model.eval()  # Switch to evaluation mode
#         correct = 0
#         total = 0
#         val_loss = 0.0
#
#         with torch.no_grad():  # 取消梯度计算
#             for batch_idx, (inputs, labels) in enumerate(val_loader):
#                 inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
#
#                 val_outputs = model(inputs)
#                 loss = criterion(val_outputs, labels)
#                 val_loss += loss.item()
#
#                 _, val_predicted = torch.max(val_outputs, 1)
#                 correct += (val_predicted == labels).sum().item()
#                 total += labels.size(0)
#
#         val_acc = 100 * correct / total
#         avg_val_loss = val_loss / len(val_loader)
#         val_acc_history.append(val_acc)
#
#         print(f"Epoch [{epoch + 1}/{args.epochs}], Validation Loss: {avg_val_loss:.4f}, Validation Accuracy: {val_acc:.2f}%")
#
#         # Save the best model based on validation accuracy
#         if val_acc > best_val_acc:
#             print(f"Validation accuracy improved from {best_val_acc:.2f}% to {val_acc:.2f}%. Saving model...")
#             best_val_acc = val_acc
#             torch.save(model.state_dict(), 'best_model.pth')  # Save the model
#
#         # Update learning rate if scheduler is enabled
#         if args.lr_scheduler:
#             scheduler.step()
#
#     # Print training and validation histories
#     print("Training History:")
#     print(f"Train Loss: {train_loss_history}")
#     print(f"Validation Accuracy: {val_acc_history}")
#
#     # Final testing
#     model.load_state_dict(torch.load('best_model.pth'))  # Load the best model
#     model.eval()  # Switch to evaluation mode
#     correct = 0
#     total = 0
#     test_loss = 0.0
#
#     with torch.no_grad():  # Disable gradient computation
#         for batch_idx, (inputs, labels) in enumerate(test_loader):
#             inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
#
#             outputs = model(inputs)  # Get model outputs
#             loss = criterion(outputs, labels)  # Compute loss
#             test_loss += loss.item()
#
#             _, predicted = torch.max(outputs, 1)  # Get predicted classes
#             correct += (predicted == labels).sum().item()  # Count correct predictions
#             total += labels.size(0)  # Total number of samples
#
#     test_acc = 100 * correct / total
#     avg_test_loss = test_loss / len(test_loader)
#
#     print(f"Test Loss: {avg_test_loss:.4f}, Test Accuracy: {test_acc:.2f}%")

if __name__ == "__main__":
    root_dir = args.data_path
    fold_name = args.fold_name

    # 初始化数据集
    folds, full_dataset, test_dataset, train_tf, val_tf = dataloader.data_load(
        root_dir, fold_name, args.batch_size, args.workers
    )

    # 训练所有模型（ResNet、MobileNetV3、EfficientNetB0）
    all_models = []
    for model_name in ['resnet18', 'mobilenet_v3_small', 'efficientnet_b0']:
        fold_models = []
        for fold, (train_idx, val_idx) in enumerate(folds):
            # 创建数据加载器
            train_dataset = CustomImageDataset(full_dataset, train_idx, train_tf)
            val_dataset = CustomImageDataset(full_dataset, val_idx, val_tf)

            # 训练并保存模型
            model = train_single_model(args, train_dataset, val_dataset, model_name)
            torch.save(model.state_dict(), f'{model_name}_fold{fold}.pth')
            fold_models.append(model)
        all_models.extend(fold_models)

    # 创建集成模型
    ensemble_model = EnsembleModel(all_models).to(DEVICE)

    # 测试评估
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size)
    all_probs = []
    all_labels = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs = inputs.to(DEVICE)
            outputs = ensemble_model(inputs)
            all_probs.append(torch.softmax(outputs, dim=1).cpu().numpy())
            all_labels.append(labels.numpy())

    # 计算指标
    y_true = np.concatenate(all_labels)
    y_prob = np.concatenate(all_probs)
    y_pred = np.argmax(y_prob, axis=1)

    print(f"Precision: {precision_score(y_true, y_pred, average='macro')}")
    print(f"Recall: {recall_score(y_true, y_pred, average='macro')}")
    print(f"F1: {f1_score(y_true, y_pred, average='macro')}")
    print(f"ROC-AUC: {roc_auc_score(y_true, y_prob, multi_class='ovr')}")
    print(f"PR-AUC: {average_precision_score(y_true, y_prob, average='macro')}")