import os
import numpy as np
import torch
from torchvision import transforms, datasets
from torch.utils.data import DataLoader, Subset
from PIL import Image


class TransformedDataset(torch.utils.data.Dataset):
    """
    完全自定义数据集类，确保transform被正确应用
    """

    def __init__(self, dataset, transform=None):
        self.dataset = dataset
        self.transform = transform

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img, label = self.dataset[idx]

        # 确保图像是PIL Image（如果是张量则转换回去）
        if isinstance(img, torch.Tensor):
            img = transforms.ToPILImage()(img)

        # 强制应用transform（确保转换为张量）
        if self.transform:
            img = self.transform(img)

        return img, label


def data_load(root_path, dir, batch_size, numworker):
    # 基础转换（仅调整大小）
    base_transform = transforms.Compose([
        transforms.Resize(256),
    ])

    # 加载原始数据集
    full_dataset = datasets.ImageFolder(
        root=os.path.join(root_path, dir),
        transform=base_transform  # 只做resize
    )

    # 按类别划分索引
    class_indices = {}
    for idx, (_, label) in enumerate(full_dataset):
        class_indices.setdefault(label, []).append(idx)

    # 分割数据集
    train_indices, val_indices, test_indices = [], [], []
    for indices in class_indices.values():
        np.random.shuffle(indices)
        n = len(indices)
        train_end = int(0.6 * n)
        val_end = train_end + int(0.2 * n)

        train_indices.extend(indices[:train_end])
        val_indices.extend(indices[train_end:val_end])
        test_indices.extend(indices[val_end:])

    # 定义各数据集的transform
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),  # 关键！必须包含
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    val_test_transform = transforms.Compose([
        transforms.CenterCrop(224),
        transforms.ToTensor(),  # 关键！必须包含
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # 创建最终数据集
    train_dataset = TransformedDataset(
        Subset(full_dataset, train_indices),
        train_transform
    )
    val_dataset = TransformedDataset(
        Subset(full_dataset, val_indices),
        val_test_transform
    )
    test_dataset = TransformedDataset(
        Subset(full_dataset, test_indices),
        val_test_transform
    )

    # 创建DataLoader（临时设置num_workers=0调试）
    train_loader = DataLoader(
        train_dataset, batch_size=batch_size,
        shuffle=True, num_workers=0  # 先禁用多线程
    )
    val_loader = DataLoader(
        val_dataset, batch_size=batch_size,
        shuffle=False, num_workers=0
    )
    test_loader = DataLoader(
        test_dataset, batch_size=batch_size,
        shuffle=False, num_workers=0
    )

    print(f"训练集样本数: {len(train_dataset)}")
    print(f"验证集样本数: {len(val_dataset)}")
    print(f"测试集样本数: {len(test_dataset)}")

    # 验证数据格式
    sample, _ = next(iter(train_loader))
    assert isinstance(sample, torch.Tensor), f"数据应为张量，实际得到{type(sample)}"

    return train_loader, val_loader, test_loader