import os
import torch
import numpy as np
from torch import nn
import argparse
import dataloader
from classifier import Model4Classifier
import matplotlib.pyplot as plt
from sklearn.metrics import (confusion_matrix, precision_recall_curve,
                            average_precision_score, roc_curve, auc,
                            precision_score, recall_score, f1_score)
from itertools import cycle

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description='Course_for_OfficeHome')
# 模型的基本参数
parser.add_argument('--backbone', type=str, default='resnet50')#resnext50_32x4d resnet50
parser.add_argument('--hidden_dim', type=int, default=512) #分类头全连接层的神经元数量
# 数据的基本参数
parser.add_argument('--data_path', default=r"D:\\desktop\\guidang1", type=str)
parser.add_argument('--fold_name', default="Real World", type=str)
parser.add_argument('--batch_size', type=int, default=32)
parser.add_argument('--class_num', type=int, default=65)
parser.add_argument('--workers', type=int, default=8)
# 训练阶段的基本参数
parser.add_argument('--epochs', type=int, default=1)
parser.add_argument('--iters_per_epoch', type=int, default=1000)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--lr_decay', type=float, default=1e-4)
parser.add_argument('--lr_scheduler', type=bool, default=True)
parser.add_argument('--momentum', type=float, default=0.9)
parser.add_argument('--decay', type=float, default=1e-3)
parser.add_argument('--temp', type=float, default=0.5)
parser.add_argument('--seed', type=int, default=42)

args = parser.parse_args()
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


if __name__ == "__main__":
    ######## 数据
    root_dir = args.data_path
    fold_name = args.fold_name
    train_loader, val_loader, test_loader = dataloader.data_load(root_dir,fold_name,args.batch_size, args.workers)

    ##### 模型
    model = Model4Classifier(args).to(DEVICE)
    criterion = nn.CrossEntropyLoss().to(DEVICE)

    optimizer = torch.optim.Adam(
        [{'params':model.backbone.parameters(), 'lr':args.lr},
         {'params':model.classifier.parameters(), 'lr':args.lr}
        ],  lr=args.lr, weight_decay=args.lr_decay)

    if args.lr_scheduler:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(args.epochs * 0.5), eta_min=1e-5)

    ##### 训练参数初始化
    best_val_acc = 0.0
    train_loss_history, val_acc_history = [], []
    all_targets = []
    all_preds = []
    all_probs = []
    for epoch in range(args.epochs):
        #### 模型训练阶段
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for batch_idx, (inputs, labels) in enumerate(train_loader):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            ### 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            ### 反向传播与优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            ### 统计训练指标
            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

        # 计算epoch训练指标
        train_loss = running_loss / len(train_loader)
        train_acc = 100. * correct / total
        train_loss_history.append(train_loss)

        print(f"Epoch [{epoch + 1}/{args.epochs}], Training Loss: {train_loss:.4f}, Training Accuracy: {train_acc:.2f}%")
        model.eval()
        epoch_targets = []
        epoch_preds = []
        epoch_probs = []

        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
                outputs = model(inputs)
                probs = torch.softmax(outputs, dim=1)
                _, preds = torch.max(outputs, 1)

                epoch_targets.extend(labels.cpu().numpy())
                epoch_preds.extend(preds.cpu().numpy())
                epoch_probs.extend(probs.cpu().numpy())

        all_targets.extend(epoch_targets)
        all_preds.extend(epoch_preds)
        all_probs.extend(epoch_probs)

    # 转换为numpy数组
    targets = np.array(all_targets)
    preds = np.array(all_preds)
    probs = np.array(all_probs)

    # 1. 绘制训练曲线
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(train_loss_history, label='Train Loss')
    plt.title('Training Loss Curve')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(val_acc_history, label='Validation Accuracy', color='orange')
    plt.title('Validation Accuracy Curve')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend()
    plt.tight_layout()
    plt.savefig('training_curves.png')
    plt.close()

    # 2. 计算分类指标
    precision = precision_score(targets, preds, average='macro')
    recall = recall_score(targets, preds, average='macro')
    f1 = f1_score(targets, preds, average='macro')

    print(f"\nClassification Metrics:")
    print(f"Average Precision: {precision:.4f}")
    print(f"Average Recall: {recall:.4f}")
    print(f"Average F1-Score: {f1:.4f}")

    # 3. ROC曲线和PR曲线（多类版本）
    # 将标签转换为one-hot形式
    n_classes = args.class_num
    y_true = np.eye(n_classes)[targets]

    # 计算每个类的ROC和PR
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    precision = dict()
    recall = dict()
    average_precision = dict()

    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_true[:, i], probs[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
        precision[i], recall[i], _ = precision_recall_curve(y_true[:, i], probs[:, i])
        average_precision[i] = average_precision_score(y_true[:, i], probs[:, i])

    # 计算宏平均
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes
    roc_auc_macro = auc(all_fpr, mean_tpr)

    # 绘制ROC曲线
    plt.figure(figsize=(8, 6))
    plt.plot(all_fpr, mean_tpr, color='b',
             label=f'Macro-average ROC (AUC = {roc_auc_macro:.2f})', lw=2)
    plt.plot([0, 1], [0, 1], 'k--', lw=2)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Macro-average ROC Curve')
    plt.legend(loc="lower right")
    plt.savefig('roc_curve.png')
    plt.close()

    # 修改PR曲线计算部分如下：

    # 首先找到所有类别中最长的recall数组长度
    max_length = max(len(recall[i]) for i in range(n_classes))

    # 对每个类别的precision和recall进行插值
    interp_precision = []
    interp_recall = np.linspace(0, 1, max_length)

    for i in range(n_classes):
        # 对precision进行插值
        p = np.interp(interp_recall, recall[i][::-1], precision[i][::-1])
        interp_precision.append(p)

    # 现在可以安全计算平均值
    mean_precision = np.mean(interp_precision, axis=0)
    mean_recall = interp_recall  # 这是我们定义的统一x轴

    # 计算平均AP
    mean_ap = np.mean([average_precision[i] for i in range(n_classes)])

    # 绘制PR曲线
    plt.figure(figsize=(8, 6))
    plt.plot(mean_recall, mean_precision, color='b',
             label=f'Macro-average PR (AP = {mean_ap:.2f})', lw=2)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.ylim([0.0, 1.05])
    plt.xlim([0.0, 1.0])
    plt.title('Macro-average Precision-Recall Curve')
    plt.legend(loc="lower left")
    plt.savefig('pr_curve.png')
    plt.close()

    # 4. 混淆矩阵
    cm = confusion_matrix(targets, preds)

    # 归一化混淆矩阵
    cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    plt.figure(figsize=(10, 8))
    plt.imshow(cm_norm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Normalized Confusion Matrix')
    plt.colorbar()

    # 添加数值标签
    thresh = cm_norm.max() / 2.
    for i in range(cm_norm.shape[0]):
        for j in range(cm_norm.shape[1]):
            plt.text(j, i, f"{cm_norm[i, j]:.2f}",
                     horizontalalignment="center",
                     color="white" if cm_norm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.savefig('confusion_matrix.png')
    plt.close()

    ### 模型验证阶段
    model.eval()  # Switch to evaluation mode
    correct = 0
    total = 0
    val_loss = 0.0

    with torch.no_grad():  # 取消梯度计算
        for batch_idx, (inputs, labels) in enumerate(val_loader):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            val_outputs = model(inputs)
            loss = criterion(val_outputs, labels)
            val_loss += loss.item()

            _, val_predicted = torch.max(val_outputs, 1)
            correct += (val_predicted == labels).sum().item()
            total += labels.size(0)

    val_acc = 100 * correct / total
    avg_val_loss = val_loss / len(val_loader)
    val_acc_history.append(val_acc)

    print(f"Epoch [{epoch + 1}/{args.epochs}], Validation Loss: {avg_val_loss:.4f}, Validation Accuracy: {val_acc:.2f}%")

    # Save the best model based on validation accuracy
    if val_acc > best_val_acc:
        best_val_acc = val_acc
        print(f"Validation accuracy improved from {best_val_acc:.2f}% to {val_acc:.2f}%. Saving model...")
        torch.save(model.state_dict(), 'best_model.pth')  # Save the model

    # Update learning rate if scheduler is enabled
    if args.lr_scheduler:
        scheduler.step()

    # Print training and validation histories
    print("Training History:")
    print(f"Train Loss: {train_loss_history}")
    print(f"Validation Accuracy: {val_acc_history}")

    # Final testing
    model.load_state_dict(torch.load('best_model.pth'))  # Load the best model
    model.eval()  # Switch to evaluation mode
    correct = 0
    total = 0
    test_loss = 0.0

    with torch.no_grad():  # Disable gradient computation
        for batch_idx, (inputs, labels) in enumerate(test_loader):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            outputs = model(inputs)  # Get model outputs
            loss = criterion(outputs, labels)  # Compute loss
            test_loss += loss.item()

            _, predicted = torch.max(outputs, 1)  # Get predicted classes
            correct += (predicted == labels).sum().item()  # Count correct predictions
            total += labels.size(0)  # Total number of samples

    test_acc = 100 * correct / total
    avg_test_loss = test_loss / len(test_loader)

    print(f"Test Loss: {avg_test_loss:.4f}, Test Accuracy: {test_acc:.2f}%")