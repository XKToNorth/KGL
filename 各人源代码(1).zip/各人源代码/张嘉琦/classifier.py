import torch
import torch.nn as nn
from numpy.distutils.lib2def import output_def
from sympy.physics.vector import outer
from torch.nn.modules.module import T

import model
import torchvision.models as models

class Model4Classifier(nn.Module):
    # Resnet+MLP
    def __init__(self, args):
        super(Model4Classifier, self).__init__()
        self.class_num = args.class_num
        self.hidden_dim = args.hidden_dim

        # classifier
        self.backbone = getattr(model, args.backbone)(pretrained=False)
        self.classifier = nn.Sequential()
        # 全连接层1
        self.classifier.add_module('fc1',nn.Linear(512, self.hidden_dim))
        self.classifier.add_module('batchnorm1d', nn.BatchNorm1d(self.hidden_dim))
        self.classifier.add_module('relu',nn.ReLU(inplace=True))
        self.classifier.add_module('dropout',nn.Dropout(p=0.7))
        self.classifier.add_module('fc2',nn.Linear(self.hidden_dim,self.class_num))

    def forward(self, x):
        feature_map = self.backbone(x)
        output = self.classifier(feature_map)

        return output


class BaseClassifier(nn.Module):
    """基类用于统一不同 backbone 的处理"""

    def __init__(self, args):
        super().__init__()
        self.class_num = args.class_num
        self.hidden_dim = args.hidden_dim

        # 初始化 backbone
        if args.backbone.startswith('resnet'):
            self.backbone = getattr(model, args.backbone)(pretrained=False)
            feature_dim = 512
        elif args.backbone == 'mobilenet_v3_small':
            self.backbone = models.mobilenet_v3_small(pretrained=False)
            self.backbone.classifier = nn.Identity()  # 移除原分类器
            feature_dim = 576
        elif args.backbone == 'efficientnet_b0':
            self.backbone = models.efficientnet_b0(pretrained=False)
            self.backbone.classifier = nn.Identity()  # 移除原分类器
            feature_dim = 1280

        # 分类头
        self.classifier = nn.Sequential(
            nn.Linear(feature_dim, self.hidden_dim),
            nn.BatchNorm1d(self.hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.7),
            nn.Linear(self.hidden_dim, self.class_num)
        )

    def forward(self, x):
        features = self.backbone(x)
        return self.classifier(features)

class EnsembleModel(nn.Module):
    """集成学习模型"""
    def __init__(self, models):
        super().__init__()
        self.models = nn.ModuleList(models)

    def forward(self, x):
        outputs = [model[x] for model in self.models]
        return torch.mean(torch.stack(outputs), dim=0)






