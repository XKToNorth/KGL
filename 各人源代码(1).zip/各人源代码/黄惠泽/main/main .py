import os
import torch
from torch import nn
import argparse
import dataloader
from classifier import Model4Classifier
import numpy as np
import matplotlib.pyplot as plt
from dataloader import data_load_with_fold
import time
from tqdm import tqdm

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

parser = argparse.ArgumentParser(description='Course_for_OfficeHome')
# 模型的基本参数
parser.add_argument('--backbone', type=str, default='resnet50')  # 默认先设置一个
parser.add_argument('--hidden_dim', type=int, default=512)
# 数据的基本参数
parser.add_argument('--data_path', type=str, default="OfficeHome")
parser.add_argument('--fold_name', type=str, default="Real World")
parser.add_argument('--batch_size', type=int, default=64)
parser.add_argument('--class_num', type=int, default=65)
parser.add_argument('--workers', type=int, default=8)
parser.add_argument('--folds', type=int, default=5)  # 增加folds超参
# 训练阶段的基本参数
parser.add_argument('--epochs', type=int, default=50)
parser.add_argument('--iters_per_epoch', type=int, default=1000)
parser.add_argument('--lr', type=float, default=1e-3)
parser.add_argument('--lr_decay', type=float, default=1e-4)
parser.add_argument('--lr_scheduler', type=bool, default=True)
parser.add_argument('--momentum', type=float, default=0.9)
parser.add_argument('--decay', type=float, default=1e-3)
parser.add_argument('--temp', type=float, default=0.5)
parser.add_argument('--seed', type=int, default=42)

args = parser.parse_args()
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def train_one_fold(args, fold, backbone):
    print(f">>> Training fold {fold+1} with backbone {backbone}")

    args.backbone = backbone

    train_loader, val_loader, test_loader = data_load_with_fold(
        args.data_path, args.fold_name,
        args.batch_size, args.workers,
        fold_idx=fold,
        folds=args.folds)
    
    model = Model4Classifier(args).to(DEVICE)
    criterion = nn.CrossEntropyLoss().to(DEVICE)
    optimizer = torch.optim.Adam(
        [{'params': model.backbone.parameters(), 'lr': args.lr},
         {'params': model.classifier.parameters(), 'lr': args.lr}
         ], lr=args.lr, weight_decay=args.lr_decay)
    if args.lr_scheduler:
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(args.epochs * 0.5), eta_min=1e-5)
    else:
        scheduler = None

    best_val_acc = 0.0

    for epoch in range(args.epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        epoch_start_time = time.time()

        # 使用 tqdm 包装训练数据加载器，用于显示批次进度条
        pbar = tqdm(enumerate(train_loader), total=len(train_loader), desc=f"Fold {fold+1} Epoch {epoch+1}/{args.epochs} Train")
        for batch_idx, (inputs, labels) in pbar:
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            outputs = model(inputs)
            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

            # 实时更新进度条后缀信息
            avg_loss = running_loss / (batch_idx + 1)
            acc = 100. * correct / total
            pbar.set_postfix(train_loss=f"{avg_loss:.4f}", train_acc=f"{acc:.2f}%")

        train_loss = running_loss / len(train_loader)
        train_acc = 100. * correct / total

        epoch_duration = time.time() - epoch_start_time

        # 验证阶段
        model.eval()
        val_loss = 0.0
        correct = 0
        total = 0

        val_start_time = time.time()

        with torch.no_grad():
            # 同理可以给验证阶段加进度条，感觉每epoch验证一般开这么细粒度可以不加，这里选不加
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                val_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                correct += (predicted == labels).sum().item()
                total += labels.size(0)

        val_acc = 100. * correct / total
        avg_val_loss = val_loss / len(val_loader)
        val_duration = time.time() - val_start_time

        print(f"Fold {fold+1} Epoch [{epoch+1}/{args.epochs}] "
              f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, "
              f"Val Loss: {avg_val_loss:.4f}, Val Acc: {val_acc:.2f}%, "
              f"Epoch Time: {epoch_duration + val_duration:.1f}s")

        # 保存最优模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), f'best_model_fold{fold+1}_{backbone}.pth')

        if scheduler:
            scheduler.step()

    print(f"Fold {fold+1} training completed. Best val acc: {best_val_acc:.2f}%")

    return best_val_acc


if __name__ == "__main__":
    backbones = ['resnet50', 'resnet152']
    results = {bk: [] for bk in backbones}

    for backbone in backbones:
        print(f"\n===== Start training backbone {backbone} =====")
        for fold in range(args.folds):
            best_acc = train_one_fold(args, fold, backbone)
            results[backbone].append(best_acc)
        avg_acc = np.mean(results[backbone])
        print(f"Average val accuracy for {backbone}: {avg_acc:.2f}%")

    # 画柱状图比较不同backbone的fold验证准确率
    folds = list(range(1, args.folds + 1))
    width = 0.35
    fig, ax = plt.subplots(figsize=(12, 6))

    ax.bar([x - width / 2 for x in folds], results['resnet50'], width, label='ResNet50')
    ax.bar([x + width / 2 for x in folds], results['resnet152'], width, label='ResNet152')

    ax.set_xlabel('Fold')
    ax.set_ylabel('Validation Accuracy (%)')
    ax.set_title('Validation Accuracy by Fold for ResNet50 and ResNet152')
    ax.set_xticks(folds)
    ax.legend()
    ax.grid(axis='y')
    plt.tight_layout()
    plt.savefig('val_acc_comparison.png', dpi=300)
    plt.show()
