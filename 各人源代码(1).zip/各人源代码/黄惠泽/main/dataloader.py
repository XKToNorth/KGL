import os
import numpy as np
import torch
from torchvision import transforms, datasets
from torch.utils.data import Dataset, DataLoader


class SubsetWithTransform(Dataset):
    """
    继承Dataset，用于给Subset添加transform。（ImageFolder本身无transform）
    """
    def __init__(self, dataset, indices, transform=None):
        self.dataset = dataset
        self.indices = indices
        self.transform = transform

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        img, label = self.dataset[self.indices[idx]]
        if self.transform:
            img = self.transform(img)
        return img, label


def data_load_with_fold(root_path, dir, batch_size, numworker, fold_idx=0, folds=5):
    """
    基于fold划分的数据加载函数，fold_idx从0开始，folds总折数。
    注意：dataset不带transform，transform通过SubsetWithTransform应用。
    """
    dataset = datasets.ImageFolder(root=os.path.join(root_path, dir), transform=None)

    # 按类别收集样本索引
    class_indices = {}
    for idx, (_, label) in enumerate(dataset):
        class_indices.setdefault(label, []).append(idx)

    train_indices = []
    val_indices = []
    test_indices = []

    # 固定种子保证repeatability
    np.random.seed(42)

    for label, indices in class_indices.items():
        indices = np.array(indices)
        np.random.shuffle(indices)
        n = len(indices)

        fold_size = int(np.ceil(n / folds))
        val_start = fold_idx * fold_size
        val_end = min(val_start + fold_size, n)

        val_idx = indices[val_start:val_end]
        train_idx = np.concatenate([indices[:val_start], indices[val_end:]])

        train_indices.extend(train_idx.tolist())
        val_indices.extend(val_idx.tolist())

        # 这里划分测试集为最后20%，跟train/val无关
        test_start = int(n * 0.8)
        test_idx = indices[test_start:]
        test_indices.extend(test_idx.tolist())

    # 定义transform
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    val_test_transform = transforms.Compose([
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    train_dataset = SubsetWithTransform(dataset, train_indices, train_transform)
    val_dataset = SubsetWithTransform(dataset, val_indices, val_test_transform)
    test_dataset = SubsetWithTransform(dataset, test_indices, val_test_transform)

    print(f"Fold {fold_idx + 1}/{folds} splits:")
    print(f"  Train samples: {len(train_dataset)}")
    print(f"  Val samples: {len(val_dataset)}")
    print(f"  Test samples: {len(test_dataset)}")

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=numworker)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=numworker)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=numworker)

    return train_loader, val_loader, test_loader
