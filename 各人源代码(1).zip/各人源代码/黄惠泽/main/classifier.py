import torch
import torch.nn as nn
import model
import torchvision.models as tv_models

class Model4Classifier(nn.Module):
    def __init__(self, args):
        super(Model4Classifier, self).__init__()
        self.class_num = args.class_num
        self.hidden_dim = args.hidden_dim
        backbone_name = args.backbone.lower()
        
        # 支持多种backbone选择
        if backbone_name in ['resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152']:
            # 使用您自定义model.py中的ResNet实现
            self.backbone = getattr(model, backbone_name)(pretrained=False)
            # 去掉原fc，替换成Identity，输出特征shape为 (batch, feature_dim)
            self.backbone.fc = nn.Identity()
            # 不同ResNet最后特征维度不同
            feature_dims = {
                'resnet18': 512,
                'resnet34': 512,
                'resnet50': 2048,
                'resnet101': 2048,
                'resnet152': 2048
            }
            feat_dim = feature_dims[backbone_name]
        
        elif backbone_name in ['efficientnet_b2']:
            # 使用torchvision提供的EfficientNet
            effnet = getattr(tv_models, backbone_name)(pretrained=False)
            self.backbone = nn.Sequential(*list(effnet.children())[:-1])  # 去掉classifier层
            feat_dim = 1408  # b0默认1280，b1,b2维度不同可扩展
            
        elif backbone_name == 'mobilenet_v2':
            mobi = tv_models.mobilenet_v2(pretrained=False)
            self.backbone = mobi.features
            feat_dim = 1280
        
        else:
            raise ValueError(f"Unsupported backbone: {args.backbone}")
        
        self.pool = nn.AdaptiveAvgPool2d((1,1))  # 统一池化到1x1
        self.classifier = nn.Sequential()
        if self.hidden_dim > 0:
            self.classifier.add_module('fc1', nn.Linear(feat_dim, self.hidden_dim))
            self.classifier.add_module('batchnorm1d', nn.BatchNorm1d(self.hidden_dim))
            self.classifier.add_module('relu', nn.ReLU(inplace=True))
            self.classifier.add_module('dropout', nn.Dropout(p=0.5))
            self.classifier.add_module('fc2', nn.Linear(self.hidden_dim, self.class_num))
        else:
            self.classifier.add_module('fc', nn.Linear(feat_dim, self.class_num))

    def forward(self, x):
        x = self.backbone(x)
        # 如果backbone输出是四维tensor，则先全局池化和展平
        if x.dim() == 4:
            x = self.pool(x)
            x = torch.flatten(x, 1)
        output = self.classifier(x)
        return output
